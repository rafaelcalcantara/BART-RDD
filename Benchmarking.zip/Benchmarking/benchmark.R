library(stochtree)
## Read data
data <- read.csv("gpa.csv")
y <- data$nextGPA
x <- data$X
x <- x/sd(x)
w <- data[,4:11]
c <- 0
n <- nrow(data)
z <- as.numeric(x>c)
h <- 0.1
test <- -h < x & x< h
w$male <- factor(w$male,ordered=FALSE)
w$bpl_north_america <- factor(w$bpl_north_america,ordered=FALSE)
w$loc_campus1 <- factor(w$loc_campus1,ordered=FALSE)
w$loc_campus2 <- factor(w$loc_campus2,ordered=FALSE)
w$loc_campus3 <- factor(w$loc_campus3,ordered=FALSE)
## BARDDT
barddt.global.parmlist <- list(standardize=T,sample_sigma_global=TRUE,sigma2_global_init=0.1)
barddt.mean.parmlist <- list(num_trees=50, min_samples_leaf=20, alpha=0.95, beta=2,
                             max_depth=20, sample_sigma2_leaf=FALSE, sigma2_leaf_init = diag(rep(0.1/150,4)))
B <- cbind(z*x,(1-z)*x, z,rep(1,n))
B1 <- cbind(rep(c,n), rep(0,n), rep(1,n), rep(1,n))
B0 <- cbind(rep(0,n), rep(c,n), rep(0,n), rep(1,n))
time.barddt.no.gfr <- system.time({
  barddt.fit = stochtree::bart(X_train= cbind(x,w), y_train=y,
                               leaf_basis_train = B, mean_forest_params=barddt.mean.parmlist,
                               general_params=barddt.global.parmlist,
                               num_mcmc=100,num_gfr=0)
})
time.barddt.yes.gfr <- system.time({
  barddt.fit = stochtree::bart(X_train= cbind(x,w), y_train=y,
                               leaf_basis_train = B, mean_forest_params=barddt.mean.parmlist,
                               general_params=barddt.global.parmlist,
                               num_mcmc=100,num_gfr=100)
})
## Univariate basis
barddt.global.parmlist <- list(standardize=T,sample_sigma_global=TRUE,sigma2_global_init=0.1)
barddt.mean.parmlist <- list(num_trees=50, min_samples_leaf=20, alpha=0.95, beta=2,
                             max_depth=20, sample_sigma2_leaf=FALSE, sigma2_leaf_init = 0.1/50)
B <- cbind(z*x)
B1 <- cbind(rep(c,n))
B0 <- cbind(rep(0,n))
time.univariate.no.gfr <- system.time({
  barddt.fit = stochtree::bart(X_train= cbind(x,w), y_train=y,
                               leaf_basis_train = B, mean_forest_params=barddt.mean.parmlist,
                               general_params=barddt.global.parmlist,
                               num_mcmc=100,num_gfr=0)
})
time.univariate.yes.gfr <- system.time({
  barddt.fit = stochtree::bart(X_train= cbind(x,w), y_train=y,
                               leaf_basis_train = B, mean_forest_params=barddt.mean.parmlist,
                               general_params=barddt.global.parmlist,
                               num_mcmc=100,num_gfr=100)
})
## S-BART
sbart.global.parmlist <- list(standardize=T,sample_sigma_global=TRUE,sigma2_global_init=0.01)
sbart.mean.parmlist <- list(num_trees=50, min_samples_leaf=20, alpha=0.95, beta=2,
                            max_depth=20, sample_sigma2_leaf=TRUE)
time.sbart.no.gfr <- system.time({
  sbart.fit = stochtree::bart(X_train= data.frame(x=x,z=z,w=w), y_train=y,
                              mean_forest_params=sbart.mean.parmlist,
                              general_params=sbart.global.parmlist,
                              num_mcmc=100,num_gfr=0)
})
time.sbart.yes.gfr <- system.time({
  sbart.fit = stochtree::bart(X_train= data.frame(x=x,z=z,w=w), y_train=y,
                              mean_forest_params=sbart.mean.parmlist,
                              general_params=sbart.global.parmlist,
                              num_mcmc=100,num_gfr=100)
})
## Times
print(time.barddt.no.gfr)
print(time.barddt.yes.gfr)
print(time.univariate.no.gfr)
print(time.univariate.yes.gfr)
print(time.sbart.no.gfr)
print(time.sbart.yes.gfr)